package com.zaero.fehlerbehebung

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.util.AtomicFile
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max

private val Navy = Color(0xFF07101A)
private val Navy2 = Color(0xFF0D1B29)
private val Gold = Color(0xFFFFC83D)
private val GoldSoft = Color(0xFFFFE39A)
private val TextWhite = Color(0xFFF6F7F9)
private val Muted = Color(0xFFB8C4CF)
private val Card = Color(0xFF10202F)
private val Red = Color(0xFFFF6B6B)

enum class UserRole { BENUTZER, PROFI }

data class ErrorItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String = "Anfahren",
    val title: String = "",
    val keywords: String = "",
    val description: String = "",
    val solution: String = "",
    val imageNames: List<String> = emptyList()
)

class ErrorRepository(private val context: Context) {
    private val dataFile = AtomicFile(File(context.filesDir, "errors.json"))
    private val imageDir = File(context.filesDir, "error_images").apply { mkdirs() }

    fun load(): List<ErrorItem> {
        if (!dataFile.exists()) return emptyList()
        return runCatching {
            val json = dataFile.openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = JSONArray(json)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val imgs = o.optJSONArray("imageNames")
                    val names = buildList {
                        if (imgs != null) for (j in 0 until imgs.length()) add(imgs.getString(j))
                    }
                    add(
                        ErrorItem(
                            id = o.getString("id"),
                            category = o.optString("category", "Anfahren"),
                            title = o.optString("title"),
                            keywords = o.optString("keywords"),
                            description = o.optString("description"),
                            solution = o.optString("solution"),
                            imageNames = names
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun saveAll(items: List<ErrorItem>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("category", item.category)
                    put("title", item.title)
                    put("keywords", item.keywords)
                    put("description", item.description)
                    put("solution", item.solution)
                    put("imageNames", JSONArray(item.imageNames))
                }
            )
        }
        val bytes = array.toString().toByteArray(Charsets.UTF_8)
        var stream: FileOutputStream? = null
        try {
            stream = dataFile.startWrite()
            stream.write(bytes)
            stream.flush()
            stream.fd.sync()
            dataFile.finishWrite(stream)
            stream = null
        } finally {
            stream?.let(dataFile::failWrite)
        }
    }

    fun copyImage(uri: Uri): String? {
        return runCatching {
            val name = "${UUID.randomUUID()}.jpg"
            val destination = File(imageDir, name)
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                FileOutputStream(destination).use { output -> input.copyTo(output) }
            }
            name
        }.getOrNull()
    }

    fun deleteImage(name: String) {
        File(imageDir, name).delete()
    }

    fun imageFile(name: String): File = File(imageDir, name)
}

class ErrorViewModel : ViewModel() {
    private var repository: ErrorRepository? = null
    var errors by mutableStateOf<List<ErrorItem>>(emptyList())
        private set

    fun init(context: Context) {
        if (repository == null) {
            repository = ErrorRepository(context.applicationContext)
            errors = repository!!.load()
        }
    }

    fun save(item: ErrorItem, removedImages: List<String> = emptyList()) {
        val updated = if (errors.any { it.id == item.id }) {
            errors.map { if (it.id == item.id) item else it }
        } else errors + item
        errors = updated
        viewModelScope.launch(Dispatchers.IO) {
            val repo = repository ?: return@launch
            repo.saveAll(updated)
            removedImages.forEach(repo::deleteImage)
        }
    }

    fun delete(item: ErrorItem) {
        val updated = errors.filterNot { it.id == item.id }
        errors = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository?.saveAll(updated)
            item.imageNames.forEach { repository?.deleteImage(it) }
        }
    }

    suspend fun addImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        repository?.copyImage(uri)
    }

    fun removeImage(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.deleteImage(name)
        }
    }

    fun imageFile(name: String): File? =
        repository?.imageFile(name)?.takeIf { it.exists() }

    fun search(query: String, category: String?): List<ErrorItem> {
        if (query.trim().length < 3 && category == null) return emptyList()
        val q = query.trim().lowercase()
        return errors.filter { item ->
            val categoryOk = category == null || item.category == category
            val text = "${item.title} ${item.keywords} ${item.description} ${item.solution}".lowercase()
            categoryOk && (q.length < 3 || text.contains(q))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ZaeroApp() }
    }
}

@Composable
fun ZaeroApp(vm: ErrorViewModel = viewModel()) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.init(context) }

    var role by rememberSaveable { mutableStateOf(UserRole.BENUTZER) }
    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var selectedCategory by rememberSaveable { mutableStateOf<String?>(null) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedErrorId by rememberSaveable { mutableStateOf<String?>(null) }
    var editorOpen by rememberSaveable { mutableStateOf(false) }
    var loginOpen by rememberSaveable { mutableStateOf(false) }
    var deleteCandidate by remember { mutableStateOf<ErrorItem?>(null) }

    val selectedError = vm.errors.firstOrNull { it.id == selectedErrorId }
    val results = remember(query, selectedCategory, vm.errors) {
        vm.search(query, selectedCategory)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Card,
            primary = Gold,
            onPrimary = Color.Black,
            onBackground = TextWhite,
            onSurface = TextWhite
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF050B12), Navy, Color(0xFF0B1724)))
                )
        ) {
            if (editorOpen && role == UserRole.PROFI) {
                ErrorEditor(
                    item = selectedError,
                    vm = vm,
                    onBack = { editorOpen = false; selectedErrorId = null },
                    onSaved = { saved, removedImages ->
                        vm.save(saved, removedImages)
                        editorOpen = false
                        selectedErrorId = null
                    }
                )
            } else {
                HomeScreen(
                    role = role,
                    query = query,
                    searchOpen = searchOpen,
                    selectedCategory = selectedCategory,
                    results = results,
                    vm = vm,
                    onMenu = { drawerOpen = true },
                    onProfile = { loginOpen = true },
                    onSearchClick = { searchOpen = true },
                    onQueryChange = { query = it },
                    onCloseSearch = { searchOpen = false; query = "" },
                    onCategory = { selectedCategory = it; drawerOpen = false },
                    onOpenError = { selectedErrorId = it.id },
                    onEdit = { selectedErrorId = it.id; editorOpen = true },
                    onAdd = { selectedErrorId = null; editorOpen = true },
                    onDelete = { deleteCandidate = it }
                )
            }

            if (drawerOpen) {
                Drawer(
                    selectedCategory = selectedCategory,
                    onClose = { drawerOpen = false },
                    onCategory = { selectedCategory = it; drawerOpen = false }
                )
            }

            if (selectedError != null && !editorOpen) {
                ErrorDetail(
                    item = selectedError,
                    vm = vm,
                    role = role,
                    onClose = { selectedErrorId = null },
                    onEdit = { editorOpen = true }
                )
            }

            if (deleteCandidate != null) {
                AlertDialog(
                    onDismissRequest = { deleteCandidate = null },
                    title = { Text("Fehler löschen?") },
                    text = { Text("\"${deleteCandidate!!.title}\" wird dauerhaft gelöscht.") },
                    confirmButton = {
                        TextButton(onClick = {
                            deleteCandidate?.let(vm::delete)
                            deleteCandidate = null
                        }) { Text("LÖSCHEN", color = Red) }
                    },
                    dismissButton = {
                        TextButton(onClick = { deleteCandidate = null }) { Text("ABBRECHEN") }
                    }
                )
            }

            if (loginOpen) {
                LoginDialog(
                    currentRole = role,
                    onDismiss = { loginOpen = false },
                    onRole = { newRole ->
                        role = newRole
                        loginOpen = false
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    role: UserRole,
    query: String,
    searchOpen: Boolean,
    selectedCategory: String?,
    results: List<ErrorItem>,
    vm: ErrorViewModel,
    onMenu: () -> Unit,
    onProfile: () -> Unit,
    onSearchClick: () -> Unit,
    onQueryChange: (String) -> Unit,
    onCloseSearch: () -> Unit,
    onCategory: (String) -> Unit,
    onOpenError: (ErrorItem) -> Unit,
    onEdit: (ErrorItem) -> Unit,
    onAdd: () -> Unit,
    onDelete: (ErrorItem) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 30.dp, start = 18.dp, end = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMenu) {
                Icon(Icons.Default.Menu, null, tint = TextWhite, modifier = Modifier.size(34.dp))
            }
            IconButton(
                onClick = onProfile,
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = .08f))
            ) {
                Icon(Icons.Default.PersonOutline, null, tint = TextWhite, modifier = Modifier.size(30.dp))
            }
        }

        Column(Modifier.padding(horizontal = 26.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    "Z",
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    color = TextWhite,
                    modifier = Modifier
                        .background(Color.Black)
                        .padding(horizontal = 10.dp, vertical = 0.dp)
                )
                Text(".AERO", fontSize = 48.sp, fontWeight = FontWeight.Black, color = Gold)
            }
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .width(72.dp)
                    .height(4.dp)
                    .background(Gold)
            )
            Text("Abteilung", fontSize = 27.sp, color = TextWhite, modifier = Modifier.padding(top = 20.dp))
            Text(
                "Fehlerbehebung",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
            Text(
                if (selectedCategory == null) "Für die beste Performance."
                else "Bereich: $selectedCategory",
                fontSize = 18.sp,
                color = GoldSoft,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (searchOpen) {
            SearchArea(
                query = query,
                results = results,
                onQueryChange = onQueryChange,
                onClose = onCloseSearch,
                onOpenError = onOpenError,
                onEdit = onEdit,
                onDelete = onDelete,
                role = role,
                vm = vm
            )
        } else {
            Spacer(Modifier.height(32.dp))
            FeatureLine(Icons.Default.School, "EXPERTISE")
            FeatureLine(Icons.Default.Lightbulb, "LÖSUNGSANSÄTZE")
            FeatureLine(Icons.Default.Settings, "MASSNAHMEN")
            FeatureLine(Icons.Default.BarChart, "OPTIMIERUNG")
            Spacer(Modifier.weight(1f))

            if (role == UserRole.PROFI) {
                OutlinedButton(
                    onClick = onAdd,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp, vertical = 8.dp)
                        .height(52.dp),
                    border = BorderStroke(1.dp, Gold),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("FEHLER HINZUFÜGEN", fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = onSearchClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp, vertical = 8.dp)
                    .height(68.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                border = BorderStroke(2.dp, Gold),
                shape = RoundedCornerShape(34.dp)
            ) {
                Icon(Icons.Default.Search, null, tint = TextWhite, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(18.dp))
                Text("FEHLERSUCHE", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Gold, modifier = Modifier.size(30.dp))
            }

            Text(
                "EXPERTS KEEP YOUR PRODUCTION RUNNING",
                color = Muted,
                fontSize = 12.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.padding(start = 34.dp, top = 18.dp, bottom = 28.dp)
            )
        }
    }
}

@Composable
private fun FeatureLine(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(Color(0x22112233))
                .then(Modifier),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.width(18.dp))
        Text(text, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
    }
}

@Composable
private fun Drawer(
    selectedCategory: String?,
    onClose: () -> Unit,
    onCategory: (String) -> Unit
) {
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxHeight()
                .width(285.dp)
                .background(Navy2)
                .padding(top = 42.dp, start = 22.dp, end = 22.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("MENÜ", color = Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, null, tint = TextWhite)
                }
            }
            Spacer(Modifier.height(22.dp))
            MenuButton("Anfahren", selectedCategory == "Anfahren") { onCategory("Anfahren") }
            MenuButton("Abstellen", selectedCategory == "Abstellen") { onCategory("Abstellen") }
            Spacer(Modifier.weight(1f))
            Text("Z.AERO • Fehlersuche", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(28.dp))
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = .58f))
                .clickable { onClose() }
        )
    }
}

@Composable
private fun MenuButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Gold else Card,
            contentColor = if (selected) Color.Black else TextWhite
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(text, modifier = Modifier.padding(vertical = 8.dp), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SearchArea(
    query: String,
    results: List<ErrorItem>,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    onOpenError: (ErrorItem) -> Unit,
    onEdit: (ErrorItem) -> Unit,
    onDelete: (ErrorItem) -> Unit,
    role: UserRole,
    vm: ErrorViewModel
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Mindestens 3 Buchstaben…", color = Muted) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Clear, null)
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = Color.White.copy(alpha = .25f)
                )
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, null, tint = TextWhite)
            }
        }
        Spacer(Modifier.height(14.dp))
        if (query.length < 3) {
            Text("Bitte mindestens 3 Buchstaben eingeben.", color = Muted)
        } else if (results.isEmpty()) {
            Text("Keine gespeicherten Fehler gefunden.", color = Muted)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(results, key = { it.id }) { item ->
                    ErrorRow(
                        item = item,
                        role = role,
                        onOpen = { onOpenError(item) },
                        onEdit = { onEdit(item) },
                        onDelete = { onDelete(item) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ErrorRow(
    item: ErrorItem,
    role: UserRole,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onOpen() },
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(item.category, color = Gold, fontSize = 13.sp)
                if (item.keywords.isNotBlank()) Text(item.keywords, color = Muted, fontSize = 12.sp)
            }
            if (role == UserRole.PROFI) {
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, null, tint = Gold) }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Red) }
            }
            Icon(Icons.Default.ChevronRight, null, tint = Gold)
        }
    }
}

@Composable
private fun ErrorDetail(
    item: ErrorItem,
    vm: ErrorViewModel,
    role: UserRole,
    onClose: () -> Unit,
    onEdit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = {
            Column {
                Text(item.title, fontWeight = FontWeight.Bold)
                Text(item.category, color = Gold, fontSize = 13.sp)
            }
        },
        text = {
            Column {
                if (item.description.isNotBlank()) {
                    Text("Fehlerbild", color = Gold, fontWeight = FontWeight.Bold)
                    Text(item.description)
                    Spacer(Modifier.height(10.dp))
                }
                Text("Behebung", color = Gold, fontWeight = FontWeight.Bold)
                Text(item.solution.ifBlank { "Noch keine Lösung hinterlegt." })
                if (item.imageNames.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.height(190.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(item.imageNames) { name ->
                            StoredImage(vm, name, Modifier.fillMaxWidth().height(88.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row {
                if (role == UserRole.PROFI) {
                    TextButton(onClick = onEdit) { Text("BEARBEITEN", color = Gold) }
                }
                TextButton(onClick = onClose) { Text("SCHLIESSEN") }
            }
        }
    )
}

@Composable
private fun StoredImage(vm: ErrorViewModel, name: String, modifier: Modifier) {
    val file = remember(name) { vm.imageFile(name) }
    val bitmap by produceState<Bitmap?>(initialValue = null, file) {
        value = file?.let { loadBitmapScaled(it, 1000, 1000) }
    }
    if (bitmap != null) {
        androidx.compose.foundation.Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = null,
            modifier = modifier.clip(RoundedCornerShape(10.dp)),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(modifier.background(Card), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Gold)
        }
    }
}

private fun loadBitmapScaled(file: File, maxWidth: Int, maxHeight: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxWidth || bounds.outHeight / sample > maxHeight) {
        sample *= 2
    }
    return BitmapFactory.decodeFile(
        file.absolutePath,
        BitmapFactory.Options().apply { inSampleSize = max(1, sample) }
    )
}

@Composable
private fun ErrorEditor(
    item: ErrorItem?,
    vm: ErrorViewModel,
    onBack: () -> Unit,
    onSaved: (ErrorItem, List<String>) -> Unit
) {
    var category by remember(item?.id) { mutableStateOf(item?.category ?: "Anfahren") }
    var title by remember(item?.id) { mutableStateOf(item?.title ?: "") }
    var keywords by remember(item?.id) { mutableStateOf(item?.keywords ?: "") }
    var description by remember(item?.id) { mutableStateOf(item?.description ?: "") }
    var solution by remember(item?.id) { mutableStateOf(item?.solution ?: "") }
    var imageNames by remember(item?.id) { mutableStateOf(item?.imageNames ?: emptyList()) }
    var addedImages by remember(item?.id) { mutableStateOf(emptyList<String>()) }
    var removedExistingImages by remember(item?.id) { mutableStateOf(emptyList<String>()) }
    var showCategoryMenu by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var savingImages by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun cancelAndCleanUp() {
        addedImages.forEach(vm::removeImage)
        onBack()
    }

    BackHandler(onBack = ::cancelAndCleanUp)

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            savingImages = true
            val newNames = uris.mapNotNull { uri -> vm.addImage(uri) }
            imageNames = imageNames + newNames
            addedImages = addedImages + newNames
            savingImages = false
        }
    }

    Column(Modifier.fillMaxSize().background(Navy)) {
        Row(
            Modifier.fillMaxWidth().padding(top = 30.dp, start = 10.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = ::cancelAndCleanUp) {
                Icon(Icons.Default.ArrowBack, null, tint = TextWhite)
            }
            Text(
                if (item == null) "FEHLER ANLEGEN" else "FEHLER BEARBEITEN",
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 30.dp)
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                Box {
                    OutlinedButton(
                        onClick = { showCategoryMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, Gold)
                    ) {
                        Text("Bereich: $category", modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ArrowDropDown, null)
                    }
                    DropdownMenu(
                        expanded = showCategoryMenu,
                        onDismissRequest = { showCategoryMenu = false }
                    ) {
                        listOf("Anfahren", "Abstellen").forEach {
                            DropdownMenuItem(
                                text = { Text(it) },
                                onClick = { category = it; showCategoryMenu = false }
                            )
                        }
                    }
                }
            }
            item { EditField("Fehlerbezeichnung *", title) { title = it } }
            item { EditField("Suchbegriffe", keywords, "z. B. sensor, druck, motor") { keywords = it } }
            item { EditField("Fehlerbild", description, "Was passiert? Was sieht der Bediener?") { description = it } }
            item { EditField("Behebung / Vorgehen *", solution, "Schritt für Schritt beschreiben…", minLines = 5) { solution = it } }

            item {
                Text("Bilder", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                if (imageNames.isEmpty()) {
                    Text("Noch keine Bilder hinzugefügt.", color = Muted)
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.height(220.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(imageNames, key = { it }) { name ->
                            Box {
                                StoredImage(vm, name, Modifier.fillMaxWidth().height(100.dp))
                                IconButton(
                                    onClick = {
                                        imageNames = imageNames - name
                                        if (name in (item?.imageNames ?: emptyList())) {
                                            removedExistingImages = removedExistingImages + name
                                        } else {
                                            addedImages = addedImages - name
                                            vm.removeImage(name)
                                        }
                                    },
                                    modifier = Modifier.align(Alignment.TopEnd)
                                ) {
                                    Icon(Icons.Default.Delete, null, tint = Color.White)
                                }
                            }
                        }
                    }
                }
                OutlinedButton(
                    enabled = !savingImages,
                    onClick = {
                        picker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, Gold)
                ) {
                    if (savingImages) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Gold, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Gold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("BILDER AUS GALERIE HINZUFÜGEN", color = TextWhite)
                }
            }

            item {
                if (errorText != null) {
                    Text(errorText!!, color = Red)
                }
                Button(
                    enabled = !savingImages,
                    onClick = {
                        if (title.isBlank() || solution.isBlank()) {
                            errorText = "Bitte Fehlerbezeichnung und Behebung ausfüllen."
                        } else {
                            val finalItem = ErrorItem(
                                id = item?.id ?: UUID.randomUUID().toString(),
                                category = category,
                                title = title.trim(),
                                keywords = keywords.trim(),
                                description = description.trim(),
                                solution = solution.trim(),
                                imageNames = imageNames
                            )
                            onSaved(finalItem, removedExistingImages)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                ) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("SPEICHERN", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun EditField(
    label: String,
    value: String,
    placeholder: String = "",
    minLines: Int = 1,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = { if (placeholder.isNotBlank()) Text(placeholder, color = Muted) },
        minLines = minLines,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold,
            cursorColor = Gold
        )
    )
}

@Composable
private fun LoginDialog(
    currentRole: UserRole,
    onDismiss: () -> Unit,
    onRole: (UserRole) -> Unit
) {
    var selected by remember { mutableStateOf(currentRole) }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("BENUTZER / PROFI") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RoleButton("Benutzer", selected == UserRole.BENUTZER) { selected = UserRole.BENUTZER }
                    RoleButton("Profi", selected == UserRole.PROFI) { selected = UserRole.PROFI }
                }
                if (selected == UserRole.PROFI) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = false },
                        label = { Text("Masterpasswort") },
                        singleLine = true,
                        visualTransformation = if (showPassword) androidx.compose.ui.text.input.VisualTransformation.None
                        else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    null
                                )
                            }
                        },
                        isError = error,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold)
                    )
                    if (error) Text("Passwort ist falsch.", color = Red)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (selected == UserRole.BENUTZER) {
                        onRole(UserRole.BENUTZER)
                    } else if (sha256(password) == MASTER_HASH) {
                        onRole(UserRole.PROFI)
                    } else {
                        error = true
                    }
                }
            ) { Text("ANMELDEN", color = Gold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ABBRECHEN") }
        }
    )
}

@Composable
private fun RoleButton(text: String, selected: Boolean, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        border = BorderStroke(1.dp, if (selected) Gold else Color.White.copy(alpha = .25f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (selected) Gold.copy(alpha = .12f) else Color.Transparent,
            contentColor = TextWhite
        )
    ) {
        Text(text)
    }
}

private const val MASTER_HASH =
    "a2f8d69325c98051abf22e217a57489a15e0254cae8b5df60507e79f08bb1fd1"

private fun sha256(value: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) }
}
