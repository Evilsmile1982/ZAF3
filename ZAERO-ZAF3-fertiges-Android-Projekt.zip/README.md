# Z.AERO Fehlersuche

Eine offline-first Android-App für eine persönliche Fehlerdatenbank.

## Enthaltene Funktionen

- Z.AERO-inspiriertes dunkles Design mit Gold-Akzenten
- Benutzer-/Profi-Auswahl oben rechts
- Profi-Zugang mit dem gewünschten Masterpasswort `Chefe`
- Nur Profi kann Fehler anlegen, bearbeiten, löschen und speichern
- Hamburger-Menü mit `Anfahren` und `Abstellen`
- Fehlersuche ab exakt 3 eingegebenen Zeichen
- Suche in Fehlerbezeichnung, Suchbegriffen, Fehlerbild und Behebung
- Fehlerdaten werden lokal und ohne Cloud gespeichert
- Lokale Bilder pro Fehler können hinzugefügt und gelöscht werden
- Abbrechen beim Bearbeiten verwirft noch nicht gespeicherte Änderungen an Bildern
- Löschen eines Fehlers verlangt eine Bestätigung
- Lokale Fehlerdatei wird atomar geschrieben, damit ein Abbruch während des Speicherns die Datenbank nicht halb überschreibt
- Android Photo Picker statt Vollzugriff auf die Fotobibliothek

## Technischer Stand

- Android / Kotlin
- Jetpack Compose + Material 3
- Android SDK 36
- minSdk 26
- Gradle 9.6 / Android Gradle Plugin 9.4
- Kein Server und keine Internetverbindung innerhalb der App erforderlich

Die verwendeten Android-Komponenten sind auf aktuelle stabile Android-/Jetpack-Versionen abgestimmt. Die Android-Dokumentation beschreibt Navigation/Compose als vorgesehenen Ansatz für moderne Compose-Apps und den Photo Picker als datensparsame Bildauswahl. 

## APK über GitHub bauen

Das Repository enthält bereits `.github/workflows/build-apk.yml`.

1. Projekt in ein GitHub-Repository hochladen.
2. GitHub öffnen → **Actions**.
3. **Build ZAERO APK** auswählen.
4. **Run workflow** starten.
5. Nach dem erfolgreichen Lauf das Artefakt **ZAERO-Fehlersuche-debug** herunterladen.
6. Die darin enthaltene `app-debug.apk` auf das Android-Handy übertragen und installieren.

Der Workflow installiert JDK 17, Android SDK 36 und Gradle 9.6 automatisch und führt `clean assembleDebug` aus. Dadurch muss auf dem PC kein Android-Studio-Setup vorhanden sein, um den GitHub-Build auszuführen.

## Passwort

Das Startpasswort ist wie gewünscht `Chefe`. Im Quellcode liegt nur dessen SHA-256-Hash. Für eine spätere Firmenversion sollte die Anmeldung auf eine echte Geräte-/Benutzer-Authentifizierung mit geschützter Geheimnisverwaltung umgestellt werden.

## Daten

Die Fehlerdaten und Bilder liegen im privaten App-Speicher. Beim Deinstallieren der App entfernt Android diesen App-Speicher normalerweise ebenfalls. Deshalb sollte vor einem Gerätewechsel später eine Backup-/Exportfunktion ergänzt werden.

## Geplante spätere Erweiterungen

- Kamera zusätzlich zur Galerie
- Fehlernummer
- Maschine / Anlage / Baugruppe
- Checklisten für die Behebung
- Favoriten
- Backup / Export / Import
- Geräteübergreifende Synchronisation
- mehrere echte Benutzer mit getrennten Rechten


## Build-Hinweis

Der GitHub-Workflow verwendet die von GitHub Actions eingerichtete Gradle-Installation. Die Datei `gradlew` ist in diesem Projekt bewusst nur ein sicherer Fallback und kein selbstenthaltender Gradle-Wrapper.
