# ZAERO Code Check

Checked before upload:

- Kotlin source delimiter balance verified.
- Master password hash verified against `Chefe`.
- Search requires 3 characters unless a menu category is selected.
- Categories are exactly `Anfahren` and `Abstellen`.
- Photo Picker is used for image selection.
- Image changes made during editing are cleaned up when editing is cancelled.
- Existing images are deleted only after a successful error save.
- Error JSON uses AndroidX `AtomicFile` and coroutine mutual exclusion for persistence.
- GitHub Actions uses JDK 17, AGP 9.4, Gradle 9.6, SDK 36 and builds `assembleDebug`.

Important: this environment does not contain the Android SDK/Gradle installation, so a real Android compilation cannot be truthfully claimed here. The authoritative compile check is the GitHub Actions build.
